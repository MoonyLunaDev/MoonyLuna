# MoonyLuna

## Overview

MoonyLuna is a lightweight application designed for bi-directional screen sharing between two devices, aimed at enhancing collaborative efficiency. Established in August 2022, MoonyLuna is maintained by a team of volunteers and remains free of charge. Built on C++, this graphical application communicates with a server using the HTTP protocol, without needing SSL/TLS handshakes. MoonyLuna leverages the EncFile encryption engine to exchange data between two devices through a server. Encryption and decryption occur client-side, and the server solely acts as a tunnel for point-to-point transmission, thereby ensuring personal privacy and data security.

MoonyLuna associates two usernames using a User Pair model. For details on configuration, see the section below. If you wish to create your own user pair on MoonyLuna's official server, please contact `apply@mail.moonyluna.com`. Your email should include two usernames (consisting of alphanumeric characters) and a brief explanation of your background and reasoning. Emails are generally processed within five days, though a response is not guaranteed. You can verify the success of your request through the MoonyLuna client.

## Download and Installation

[Download the MoonyLuna client directly](http://www.moonyluna.com/MoonyLuna.zip).

After downloading, extract the zip file to your desired location.

- **Windows**: Simply double-click `MoonyLuna.exe` to run the application.
- **Linux**: Run `sudo apt-get install wine` in the terminal to support exe file execution, then start the program by entering `wine MoonyLuna.exe` in the terminal.

## Configuration

The `settings.txt` file is your configuration file, and modifying its contents can personalize your experience. The specific entries are as follows:

- **`user`**: One of the two associated usernames.
- **`key`**: A user-defined 48-character hexadecimal string (e.g., `0123456789abcdef0123456789abcdef0123456789abcdef`) used for encryption. Both MoonyLuna clients in a pair must share the same key.
- **`interval`**: Time interval between server requests. Options are `instant`, `brief`, `moderate`, and `extended`.
- **`resolution`**: Resolution of the uploaded images. Options are `high`, `medium`, and `low`.
- **`chatcolor`**: Color of the uploaded chat text. Options include `red`, `yellow`, `blue`, `orange`, `green`, `purple`, `black`, `white`, `gray`, `pink`, `brown`, `cyan`, `lime`, `maroon`, `rose`, `banana`, `tan`, and `coral`.

## Features

- **Adjust Window Transparency**: Click left or right mouse button.
- **Resize Window**: Scroll the mouse wheel up or down.
- **Hold Mode**: Press `H` to toggle Hold mode, which replaces the uploaded screen image with a blank image.
- **Top Mode**: Press `T` to toggle Top mode, placing the application window above other windows.
- **Chat Mode**: Press `C` to enter Chat mode and `ESC` to exit. In Chat mode, you can send short messages to notify the other party.

Enjoy using MoonyLuna for efficient and secure screen sharing!